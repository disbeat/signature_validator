To run our application, there's a graphical interface in the mainwindow.m file.

Just run the command "mainwindow" in the command line of matlab and the GUI should open. More information on how to use this interface is available in the project report.