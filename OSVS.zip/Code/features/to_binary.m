function result =  to_binary(img)
	result = img / 255;	
	
	
	
end