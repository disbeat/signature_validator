function inverted = invert(im) 
	inverted = int16(~im);
end