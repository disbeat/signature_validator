addpath('features')
addpath('classifiers')
addpath('performance')
signatures_path = 'D:\firmasGPDS960bw300';
if(ismac)
	%signatures_path = '~/Support/SignaturesDataBase/firmasGPDS960bw300';
    signatures_path = '~/Documents/SignaturesDataBase';
end
